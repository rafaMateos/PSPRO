<?php
/**
 * Created by PhpStorm.
 * User: rafa
 * Date: 13/10/18
 * Time: 10:07
 */

echo 'Hola guapo';

echo 'hola';
