<html>
<body>

<form action="resultado.php" method="post">

    Nombre: <input type="text" name="nombre"><br>
    E-mail: <input type="text" name="email"><br>
    Hombre <input type="radio" name="sexo" value="Hombre"><br>
    Mujer <input type="radio" name="sexo" value="Mujer"><br>
    Otro <input type="radio" name="sexo" value="Otro"><br>
    Licencia <input type="checkbox" name="licencia"><br>

    <input type="submit"> <br> <br> <br>

</form>




    <p>Ejercicios clase textos</p>

<form method="post" action="resultadolista.php">


     Cuenta el numero de palabras
    <input type="text" name="texto" >


    <br>

    Cuenta el numero de palabras
    <input type="text" name="texto2" >
    <input type="text" name="palabra" >

    <br>

    <input type="submit">


</form>












</body>
</html> 