<?php
/**
 * Created by PhpStorm.
 * User: migue
 * Date: 25/08/16
 * Time: 16:02
 */

namespace Constantes_DB;
class tabla1
{
    const TABLE_NAME = "Alumnos";
    const ID = "id";
    const NOMBRE = "nombre";
    const APELLIDOS = "apellidos";
    const EDAD = "edad";

}