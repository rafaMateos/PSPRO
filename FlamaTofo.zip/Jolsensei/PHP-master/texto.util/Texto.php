<?php

echo "A ver si va ";

/**
 * Created by PhpStorm.
 * User: jobando
 * Date: 15/10/18
 * Time: 10:49
 */
class Texto
{



}